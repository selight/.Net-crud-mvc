﻿namespace Todo.Mvc.Ui.Models
{
  public class Todo : SmartIT.Employee.MockDB.Todo
  {
  }


}
